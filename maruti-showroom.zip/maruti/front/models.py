from django.db import models

# Create your models here.
class Products(models.Model):
	model=models.CharField(max_length=30)



	def __init__(self):
		return self.model