from django.db import models

# Create your models here.
class MyTable(models.Model):
	name = models.CharField(max_length=80)


class news(models.Model):
	heading = models.CharField(max_length=100)
	date = models.DateTimeField()

class states(models.Model):
	statename = models.CharField(max_length=20)

	def __str__(self):
		return self.statename

class city(models.Model):
	city_name = models.CharField(max_length=30)
	state_name = models.ForeignKey(states,on_delete =models.CASCADE)

	def __str__(self):
		return self.city_name+','+self.states_name.statename


