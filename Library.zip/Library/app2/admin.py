from django.contrib import admin

# Register your models here.
from .models import MyTable,news,city,states

admin.site.register(MyTable)
admin.site.register(news)
admin.site.register(city)
admin.site.register(states)

