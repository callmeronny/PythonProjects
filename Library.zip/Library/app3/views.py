from django.http import HttpResponse
from django.shortcuts import render,redirect
from .models import bus
from .forms import StudentForm,HotelModelForm

# Create your views here.
def akshay(request):
	return HttpResponse("<h1>http response</h1>")



def shahrukh(request):
	return HttpResponse("<h2>hello shahrukh</h2>")

def resume(request):
	return render(request,'app3/welcome.html')

def hello(request):
	return render(request,'app3/hello.html')

def front(request):
	mybus = bus.objects.all()
	return render(request,'app3/front.html',{'buses':mybus})

def resumee(request):
	return render(request,'resume.html')
def contact(request):
	return render(request,'app3/contact.html')

def hotelform(request):
	return render(request,'app3/hotelform.htm')
def forms(request):
	studentform=StudentForm()
	return render(request,'app3/forms.html',{'form':studentform})
def hotelmodel(request):
	hotelmodel=HotelModelForm(request.POST or None)
	if request.method =="POST":
		if hotelmodel.is_valid():
			hotelmodel.save()
			return redirect('/Hello')
	return render(request,'app3/hotelmodel.html',{'form':hotelmodel})


