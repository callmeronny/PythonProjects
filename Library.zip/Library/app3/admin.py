from django.contrib import admin

# Register your models here.
from .models import MyTable,news,city,states,bus,Hotel

admin.site.register(MyTable)
admin.site.register(news)
admin.site.register(city)
admin.site.register(states)
admin.site.register(bus)
admin.site.register(Hotel)
