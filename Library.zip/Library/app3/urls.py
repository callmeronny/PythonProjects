
from django.urls import path
from . import views

urlpatterns = [
    path('Computer/', views.akshay),
    path('Laptop/', views.shahrukh),
    path('Resume/',views.resume),
    path('Hello/',views.hello),
    path('Front/',views.front),
    path('Resumee/',views.resumee),
    path('Contact/',views.contact),
    path('Hotel/',views.hotelform),
    path('Forms/',views.forms),
    path('Modelhotel/',views.hotelmodel),
] 