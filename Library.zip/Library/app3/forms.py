from django import forms
from .models import Hotel
#class forms 
class StudentForm(forms.Form):
	
	name=forms.CharField(widget=forms.TextInput(
		attrs={
		"class":"form-control",
		"placeholder":"Enter Name",
		"required":"required",

		}
		)
	)
	PhoneNo=forms.CharField(widget=forms.TextInput(
		attrs={
		"class":"form-control",
		"placeholder":"Enter Phone Number",
		"required":"required",
		}
		)
	)
	Age=forms.CharField(widget=forms.TextInput(
		attrs={
		"class":"form-control",
		"placeholder":"Enter Age",
		"required":"required",
		}
		)
	)
	Branch=forms.CharField(widget=forms.TextInput(
		attrs={
		"class":"form-control",
		"placeholder":"Enter Branch",
		"required":"required",
		}
		)
	)
	

#Model form
class HotelModelForm(forms.ModelForm):

	class Meta:
		model=Hotel
		#for all field-'__all__',for some selected fields-[].
		fields='__all__'
		widgets={

		'Name':forms.TextInput(attrs={'class':'form-control'}),
		'PhoneNo':forms.TextInput(attrs={'class':'form-control'}),
		'website':forms.TextInput(attrs={'class':'form-control'}),
		'Address':forms.TextInput(attrs={'class':'form-control'}),
		}

		