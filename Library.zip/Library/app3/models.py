from django.db import models

# Create your models here.

class MyTable(models.Model):
	name = models.CharField(max_length=80)


class news(models.Model):
	heading = models.CharField(max_length=100)
	date = models.DateTimeField()

class states(models.Model):
	statename = models.CharField(max_length=20)

	def __str__(self):
		return self.statename

class city(models.Model):
	citynames = models.CharField(max_length=30,unique=True)
	state_names = models.ForeignKey(states,on_delete =models.PROTECT)

	def __str__(self):
		return self.citynames+','+self.state_names.statename


class bus(models.Model):
	bus_number = models.CharField(max_length=10)
	college_bus_number = models.CharField(max_length=10)
	driver_name = models.CharField(max_length=20)
	cleaner_name = models.CharField(max_length=20)
	stops = models.TextField()
	driver_phone = models.CharField(max_length=10)
	cleaner_phone = models.CharField(max_length=10)


	def __str__(self):
		return self.bus_number+','+self.college_bus_number+','+self.driver_name+','+self.cleaner_name+','
		+self.stops+','+self.driver_phone+','+self.cleaner_phone


class Hotel(models.Model):
	Hotel_Name=models.CharField(max_length=30)
	Address=models.CharField(max_length=80)
	Rooms=models.CharField(max_length=10)
	Hotel_URL=models.CharField(max_length=30)
	def __str__(self):
		return self.Hotel_Name