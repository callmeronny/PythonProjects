from django.shortcuts import render

# Create your views here.
def template(request):
	request render(request,'app4/templates.html')