from django.contrib import admin

# Register your models here.
from.models import Student,Employee,Person,Album,Musician
admin.site.register(Student)

#from.models import Person
admin.site.register(Person)

#from.models import Musician
admin.site.register(Musician)

#from.models import Album
admin.site.register(Album)


admin.site.register(Employee)