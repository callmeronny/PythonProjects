from django.db import models
from django.utils.timezone import utc

COLLEGE_NAME=[('MIT','MILLENIUM'),('UIT','UNIVERSITY INSTITUTE'),('TIT','TRINITY')]




# Create your models here.
class Student(models.Model):
	DEPARTMENT_NAME=[('CSE','COMPUTER SCIENCE'),('IT','INFORMATION OF TECHNOLOGY'),('EX','ELECTRONICS')]
	name = models.CharField(max_length=80)
	Phoneno = models.CharField(max_length=10)
	age = models.CharField(max_length=2)
	collegename = models.CharField(max_length=20,choices=COLLEGE_NAME)
	department = models.CharField(max_length=30,choices=DEPARTMENT_NAME)
	
	
	
	
	def __str__(self):
		return self.name+","+self.Phoneno+","+self.age+","+self.collegename+","+self.department
	
	
	
class Person(models.Model):
	first_name = models.CharField(max_length=20)
	last_name = models.CharField(max_length=10)
	birth_date = models.DateField()
	email_add = models.EmailField()
	binary_data = models.BinaryField()
	Boolean_field = models.BooleanField()
	time_field = models.TimeField()
	date_time = models.DateTimeField()
	duration = models.DurationField()
	float_fields = models.FloatField()
	integer = models.IntegerField()
	positive_integer = models.PositiveIntegerField()
	text = models.TextField()
	file = models.FileField()
	filepath = models.FilePathField()
	url = models.URLField()
	slug = models.SlugField()
	
	UUID = models.UUIDField()
	image_field = models.ImageField()
	
	
	

	
	
	
	def __str__(self):
		return self.first_name+","+self.last_name+","+self.birth_date+','+self.email_add+','+self.binary_data+','
		+self.Boolean_field+','+self.time_field+','+self.date_time+','+self.duration+','+self.float+','+self.integer+','
		+self.positive_integer+','+self.text+','+self.file+','+self.filepath+','+self.url+','+self.slug+','
		+self.UUID+','+self.image_field


class Musician(models.Model):
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    instrument = models.CharField(max_length=100)
	
class Album(models.Model):
    artist = models.ForeignKey(Musician, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    release_date = models.DateField()
    num_stars = models.IntegerField()
	
	

class Employee(models.Model):
	first_name = models.CharField(db_column='fname',max_length=10)
	last_name = models.CharField(db_column='lname',max_length=10)
	salary = models.IntegerField(primary_key=True)
	email = models.EmailField(help_text='abc@gmail.com',max_length=80)
	department_name = models.CharField(max_length=10)
	randomfield = models.CharField(max_length=10,default="sunil ji")
	
	def __str__(self):
		return self.first_name + "  "+ self.last_name +"  "
		
	
	
	
	