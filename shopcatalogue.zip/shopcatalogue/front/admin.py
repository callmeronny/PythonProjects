from django.contrib import admin
from .models import UserProfiles,City

# Register your models here.

admin.site.register(UserProfiles)
admin.site.register(City)
